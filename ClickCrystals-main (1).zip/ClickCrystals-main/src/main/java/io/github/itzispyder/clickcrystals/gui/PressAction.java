package io.github.itzispyder.clickcrystals.gui;

public interface PressAction {

    void onPress(DisplayableElement button);
}

package io.github.itzispyder.clickcrystals.data;

public record Delta(int x, int y, int z) {

}

package io.github.itzispyder.clickcrystals.client;

public final class EntityStatusType {

    public static final int
            DEATH = 3,
            TOTEM_POP = 35;
}

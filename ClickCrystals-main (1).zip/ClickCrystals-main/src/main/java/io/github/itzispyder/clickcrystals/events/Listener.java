package io.github.itzispyder.clickcrystals.events;

import java.io.Serializable;

/**
 * Listener interface, apply this to objects that contains events
 * for the listener.
 */
public interface Listener extends Serializable {

}

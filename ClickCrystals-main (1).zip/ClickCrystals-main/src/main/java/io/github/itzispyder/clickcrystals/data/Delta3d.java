package io.github.itzispyder.clickcrystals.data;

public record Delta3d(double x, double y, double z) {

}

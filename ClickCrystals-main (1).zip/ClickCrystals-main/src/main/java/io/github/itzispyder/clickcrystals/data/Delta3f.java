package io.github.itzispyder.clickcrystals.data;

public record Delta3f(float x, float y, float z) {

}

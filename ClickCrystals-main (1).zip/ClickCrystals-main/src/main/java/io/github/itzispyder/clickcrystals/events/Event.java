package io.github.itzispyder.clickcrystals.events;

/**
 * Represents a passable event
 */
public abstract class Event {

}

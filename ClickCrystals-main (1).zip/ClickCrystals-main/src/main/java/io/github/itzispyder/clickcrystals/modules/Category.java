package io.github.itzispyder.clickcrystals.modules;

import java.io.Serializable;

public record Category(String name) implements Serializable {

}

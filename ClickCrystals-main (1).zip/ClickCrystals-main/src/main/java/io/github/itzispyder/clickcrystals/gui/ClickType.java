package io.github.itzispyder.clickcrystals.gui;

public enum ClickType {

    RELEASE,
    CLICK
}

package io.github.itzispyder.clickcrystals.modules.modules.misc;

import io.github.itzispyder.clickcrystals.modules.Categories;
import io.github.itzispyder.clickcrystals.modules.Module;

public class SlowSwing extends Module {

    public SlowSwing() {
        super("SlowHandSwing", Categories.MISC,"Makes your hand swing as if you had mining fatigue.");
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
